setwd("C:/Users/Hannes/switchdrive/Thesis")

library(RHugin)

BayesNet <- read.rhd("BN_Reduced_Sim3.net")

LR <- function(BayesNet, alpha, beta, gama, delta, theta, e1_1, e1_2, e3_1, e3_2, e4_1, e4_2, P_user1, P_user2){
  
  tabUseP <- get.table(BayesNet, 'UseP')
  tabUseP[1,'Freq'] = alpha
  tabUseP[2,'Freq'] = beta
  tabUseP[3,'Freq'] = 1-alpha-beta
  tabUseP[4,'Freq'] = gama
  tabUseP[5,'Freq'] = delta
  tabUseP[6,'Freq'] = 1-gama-delta
  set.table(BayesNet, 'UseP', tabUseP)
  
  tabE1 <- get.table(BayesNet, 'E1')
  tabE1[1,'Freq'] = e1_1
  tabE1[2,'Freq'] = 1-e1_1
  tabE1[3,'Freq'] = e1_2
  tabE1[4,'Freq'] = 1-e1_2
  set.table(BayesNet, 'E1', tabE1)
  
  tabE3 <- get.table(BayesNet, 'E3')
  tabE3[1,'Freq'] = e3_1
  tabE3[2,'Freq'] = 1-e3_1
  tabE3[3,'Freq'] = e3_2
  tabE3[4,'Freq'] = 1-e3_2
  set.table(BayesNet, 'E3', tabE3)
  
  tabE4 <- get.table(BayesNet, 'E4')
  tabE4[1,'Freq'] = e4_1
  tabE4[2,'Freq'] = 1-e4_1
  tabE4[3,'Freq'] = e4_2
  tabE4[4,'Freq'] = 1-e4_2
  set.table(BayesNet, 'E4', tabE4)
  
  tabUser <- get.table(BayesNet, 'User')
  tabUser[1,'Freq'] = P_user1
  tabUser[2,'Freq'] = P_user2
  tabUser[3,'Freq'] = 1 - P_user1 -P_user2
  
  tabUseU <- get.table(BayesNet, 'UseU')
  tabUseU[13,'Freq'] = theta
  tabUseU[14,'Freq'] = 1-theta
  
  compile(BayesNet)
  set.finding(BayesNet, 'E1', 'E1')
  set.finding(BayesNet, 'E3', 'E3')
  set.finding(BayesNet, 'E4', 'E4')
  propagate(BayesNet)
  odds <- get.belief(BayesNet, 'LocP')
  uncompile(BayesNet)
  
  lr <- odds['LocP1'] / odds['LocP2']
  
  return(lr[['LocP1']])
}


resolution = 100

e1_1 = 1
e1_2 = 0.001
e3_1 = 1
e3_2 = 0.001
e4_1 = 1
e4_2 = 0.001
useP1 = 0.5
theta = 0.8

lr_vector <- function(alpha){
  lr_vec = vector()
  for (counter in c(0:resolution)){
    y_val = counter/resolution
    lr = LR(BayesNet = BayesNet, alpha = alpha, beta = (1 - alpha) * fac_bet, gama = y_val, delta = (1 - y_val) * fac_delta, P_user1 = useP1, P_user2 = 1-useP1, e1_1 = e1_1, e1_2 = e1_2, e3_1 = e3_1, e3_2 = e3_2, e4_1 = e4_1, e4_2=e4_2, theta = theta)
    lr_vec <- rbind(lr_vec, c(y_val, lr))
  } 
  return(lr_vec)  
}

ylim_top = 1400

fac_bet = 0.9
fac_delta = 1
plot(lr_vector(0.9), xlim = c(0,1),ylim=c(0,ylim_top), xlab = 'gamma', ylab = 'LR', type = 'l', main = 'gamma varied, alpha fixed, delta = 1 - gamma')
lines(lr_vector(0.5), lty = 2)
lines(lr_vector(0.1), lty = 4)
abline(h=1, lty = 3)
legend(x=0,y=ylim_top,cex=0.6,legend = c('alpha = 0.9', 'alpha = 0.5', 'alpha = 0.1'), lty=c(1,2,4))


fac_delta=0.9
plot(lr_vector(0.9), xlim = c(0,1),ylim=c(0,ylim_top), xlab = 'gamma', ylab = 'LR', type = 'l', main = 'gamma varied, alpha fixed, delta = 0.9(1 - gamma)')
lines(lr_vector(0.5), lty = 2)
lines(lr_vector(0.1), lty = 4)
abline(h=1, lty = 3)
legend(x=0,y=ylim_top,cex=0.6,legend = c('alpha = 0.9', 'alpha = 0.5', 'alpha = 0.1'), lty=c(1,2,4))


fac_delta=0.5
plot(lr_vector(0.9), xlim = c(0,1),ylim=c(0,ylim_top), xlab = 'gamma', ylab = 'LR', type = 'l', main = 'gamma varied, alpha fixed, delta = 0.5(1 - gamma)')
lines(lr_vector(0.5), lty = 2)
lines(lr_vector(0.1), lty = 4)
abline(h=1, lty = 3)
legend(x=0,y=ylim_top,cex=0.6,legend = c('alpha = 0.9', 'alpha = 0.5', 'alpha = 0.1'), lty=c(1,2,4))

fac_delta=0.1
plot(lr_vector(0.9), xlim = c(0,1),ylim=c(0,ylim_top), xlab = 'gamma', ylab = 'LR', type = 'l', main = 'gamma varied, alpha fixed, delta = 0.1(1 - gamma)')
lines(lr_vector(0.5), lty = 2)
lines(lr_vector(0.1), lty = 4)
abline(h=1, lty = 3)
legend(x=0,y=ylim_top,cex=0.6,legend = c('alpha = 0.9', 'alpha = 0.5', 'alpha = 0.1'), lty=c(1,2,4))
