setwd("C:/Users/Hannes/switchdrive/Thesis")

library(RHugin)

BayesNet <- read.rhd("BN_Reduced_Sim1.net")

resolution = 100


LR <- function(BayesNet, useP1, useP2, e1_1, e1_2){
  
  tabUseP <- get.table(BayesNet, 'UseP')
  tabUseP[1,'Freq'] = useP1
  tabUseP[2,'Freq'] = useP2
  tabUseP[3,'Freq'] = 1-useP1-useP2
  set.table(BayesNet, 'UseP', tabUseP)
  
  tabE1 <- get.table(BayesNet, 'E1')
  tabE1[1,'Freq'] = e1_1
  tabE1[2,'Freq'] = 1-e1_1
  tabE1[3,'Freq'] = e1_2
  tabE1[4,'Freq'] = 1-e1_2
  set.table(BayesNet, 'E1', tabE1)

  compile(BayesNet)
  set.finding(BayesNet, 'E1', 'E1')
  propagate(BayesNet)
  odds <- get.belief(BayesNet, 'LocP')
  uncompile(BayesNet)
  
  lr <- odds['LocP1'] / odds['LocP2']
  
  return(lr[['LocP1']])
}


lr_vector <- function(e1_1, e1_2){
  lr_delta = vector()
  for (counter in c(0:resolution)){
    useP1 = counter/resolution
    lr = LR(BayesNet = BayesNet, useP1 = useP1, useP2 = 1-useP1, e1_1 = e1_1, e1_2 = e1_2)
    lr_delta <- rbind(lr_delta, c(useP1, lr))
  } 
  return(lr_delta)  
}


plot(lr_vector(1, 0.1), xlim = c(0,1),ylim=c(0,120), xlab = 'Pr(UseP1)', ylab = 'LR', type = 'l', main = 'LR on person-level (varying Pr(UseP1))')


lines(lr_vector(1,0.01), lty = 2)


lines(lr_vector(1,0.001), lty = 4)

abline(h=1, lty = 3)
legend(x=0,y=120,cex=0.7,legend = c('LR_dev = 10', 'LR_dev = 100', 'LR_dev = 1000'), lty=c(1,2,4))
