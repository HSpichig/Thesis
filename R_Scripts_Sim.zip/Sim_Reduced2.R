setwd("C:/Users/Hannes/switchdrive/Thesis")

library(RHugin)

BayesNet <- read.rhd("BN_Reduced_Sim2.net")




LR <- function(BayesNet, useP1, useP2, e1_1, e1_2, e2_1, e2_2){
  
  tabUseP <- get.table(BayesNet, 'UseP')
  tabUseP[1,'Freq'] = useP1
  tabUseP[2,'Freq'] = useP2
  tabUseP[3,'Freq'] = 1-useP1-useP2
  set.table(BayesNet, 'UseP', tabUseP)
  
  tabE1 <- get.table(BayesNet, 'E1')
  tabE1[1,'Freq'] = e1_1
  tabE1[2,'Freq'] = 1-e1_1
  tabE1[3,'Freq'] = e1_2
  tabE1[4,'Freq'] = 1-e1_2
  set.table(BayesNet, 'E1', tabE1)

  tabE2 <- get.table(BayesNet, 'E2')
  tabE2[1,'Freq'] = e2_1
  tabE2[2,'Freq'] = 1-e2_1
  tabE2[3,'Freq'] = e2_2
  tabE2[4,'Freq'] = 1-e2_2
  set.table(BayesNet, 'E2', tabE2)
  
  compile(BayesNet)
  set.finding(BayesNet, 'E1', 'E1')
  set.finding(BayesNet, 'E2', 'E2')
  propagate(BayesNet)
  odds <- get.belief(BayesNet, 'LocP')
  uncompile(BayesNet)
  
  lr <- odds['LocP1'] / odds['LocP2']
  
  return(lr[['LocP1']])
}


lr_vector <- function(e1_1, e1_2, e2_1, e2_2){
  lr_delta = vector()
  for (counter in c(0:resolution)){
    useP1 = counter/resolution
    lr = LR(BayesNet = BayesNet, useP1 = useP1, useP2 = 1-useP1, e1_1 = e1_1, e1_2 = e1_2, e2_1 = e2_1, e2_2 = e2_2)
    lr_delta <- rbind(lr_delta, c(useP1, lr))
  } 
  return(lr_delta)  
}

resolution = 100

sim_run <- function(e2_1, e2_2, y_lim){
  LR_P = e2_1 / e2_2
  title = paste('LR on person-level \n(varying Pr(UseP1), LR(E2)=', LR_P, ')')
  plot(lr_vector(1, 0.1, e2_1, e2_2), xlim = c(0,1),ylim=c(0,y_lim), xlab = 'Pr(UseP1)', ylab = 'LR', type = 'l', main = title)
  lines(lr_vector(1, 0.01, e2_1, e2_2), lty = 2)
  lines(lr_vector(1, 0.001, e2_1, e2_2), lty = 4)
  abline(h=1, lty = 3)
  legend(x=0,y=y_lim,cex=0.7,legend = c('LR_dev = 10', 'LR_dev = 100', 'LR_dev = 1000'), lty=c(1,2,4))
}


sim_run(1, 0.1, 150)
sim_run(1, 0.01, 1100)
sim_run(1, 0.001, 1100)
